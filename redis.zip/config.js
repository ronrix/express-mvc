
const PORT = 8000;

const db_config = {
	server_name: "localhost",
	username: "wp_user",
	password: "WP_password12",
	dbname: "express_debugger",
	port: 3306,
}

module.exports = {
	PORT,
	db_config,
}

/*
	DOCU: this file is for db configuration and other global variables
	OWNER: ronrix
*/ 